// import React from 'react';
// import {Route, Routes} from "react-router-dom";
// import Fonts from "../Fonts";
// import BuyFonts from "../BuyFonts";
// import {routesList} from "./routesList";
//
// const Routers = () => {
//     return (
//         <Routes>
//             {routesList.map(item =>
//                 <Route key={item.path} path={item.path} element={<item.element/>}/>
//             )}
//         </Routes>
//     );
// };
//
// export default Routers;