// import Fonts from "../Fonts";
// import BuyFonts from "../BuyFonts";
//
// export const routesList = [
//     {
//         path: '/myFonts',
//         element: Fonts,
//     },
//     {
//         path: '/buyFonts',
//         element: BuyFonts,
//     },
//     {
//         path: '*',
//         element: Fonts,
//     }
// ];